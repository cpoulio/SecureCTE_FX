Example VRALib scripts:

Example-AddHostKey.vbs
  This short example script shows how to add keys to the SSH2
  host key database.

Example-Agent.vbs
  This short example script prompts for the private key path
  and passphrase and adds the key to the SSH2 authentication
  agent.

Example-Connect.vbs
  This sample script shows the basics of how to get connected;
  it doesn't do anything with the connections it makes.

Example-RemoteFindFilesViaSFTP.vbs
  This script creates a web page that can be used to connect
  to a remote SSH2 server, specify a string to search for in
  the current working directory and subdirectories.

Example-WriteToExcelFile.vbs
  This script connects to an SSH2 server, runs the UNIX/Linux
  command "uptime", and writes the current date and the
  results of the "uptime" command into the first blank row in
  the specified Excel spreadsheet.
